"""
PeerLink — Zero-config P2P RPC over LAN/WiFi.

High-level API:
  - PeerLink: core node type
  - SwarmNode: convenience wrapper that auto-starts
  - PeerProxy: attribute-based remote calls
  - Exceptions: PeerLinkError, PeerNotFound, PeerNotFoundError,
                PeerTimeoutError, RemoteError
"""

from __future__ import annotations

from .core import (
    DISCOVERY_WAIT,
    PeerLink,
    PeerLinkError,
    PeerNotFound,
    PeerNotFoundError,
    PeerProxy,
    PeerTimeoutError,
    RemoteError,
    SwarmNode,
    __version__,
)

__all__ = [
    "PeerLink",
    "SwarmNode",
    "PeerProxy",
    "PeerLinkError",
    "PeerNotFound",
    "PeerNotFoundError",
    "PeerTimeoutError",
    "RemoteError",
    "DISCOVERY_WAIT",
    "__version__",
]

