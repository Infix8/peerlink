"""
Core PeerLink P2P RPC implementation.

Zero-config P2P RPC over LAN/WiFi using:
  - mDNS discovery (zeroconf)
  - UDP transport
  - JSON message framing
"""

from __future__ import annotations

import hashlib
import json
import logging
import socket
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

from zeroconf import ServiceBrowser, ServiceInfo, ServiceListener, Zeroconf

__all__ = [
    "PeerLink",
    "SwarmNode",
    "PeerProxy",
    "PeerLinkError",
    "PeerNotFound",
    "PeerNotFoundError",
    "PeerTimeoutError",
    "RemoteError",
    "arp_scan",
    "__version__",
]

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────
__version__ = "1.0.0"

# mDNS service type for PeerLink nodes
SERVICE_TYPE = "_peerlink._tcp.local."

# UDP transport configuration
BASE_PORT = 49152  # IANA dynamic/ephemeral range start
PORT_RANGE = 16383  # 49152 – 65535
RPC_TIMEOUT = 5.0  # seconds
MAX_DATAGRAM = 65535  # absolute upper bound for UDP payload
PEER_TTL = 60.0  # seconds before a peer entry expires
DISCOVERY_WAIT = 3.0  # seconds to let mDNS settle on start

logger = logging.getLogger("peerlink")


# ─────────────────────────────────────────────────────────────────────────────
# Exceptions
# ─────────────────────────────────────────────────────────────────────────────
class PeerLinkError(Exception):
    """Base class for PeerLink-specific errors."""


class PeerNotFound(PeerLinkError):
    """Raised when the target peer is not in the discovery table or has expired."""


class RemoteError(PeerLinkError):
    """Raised when the remote node returns an error payload."""


class PeerNotFoundError(PeerNotFound):
    """Backward-compatible alias for older name used in docs/demos."""


class PeerTimeoutError(TimeoutError, PeerLinkError):
    """Raised when an RPC call does not receive a reply within the timeout."""


@dataclass
class PeerInfo:
    name: str
    addr: str
    port: int
    last_seen: float
    ttl: float = PEER_TTL


@dataclass
class PendingCall:
    id: str
    event: threading.Event
    result: Optional[dict] = None


class PeerProxy:
    """Lightweight proxy for attribute-based remote calls: peer.add(1, 2)."""

    def __init__(self, node: "PeerLink", name: str):
        self._node = node
        self._name = name

    def __repr__(self) -> str:
        return f"<PeerProxy name={self._name!r}>"

    def __getattr__(self, func_name: str) -> Callable[..., Any]:
        # Return a callable that forwards to PeerLink.call
        def _caller(*args, timeout: float = RPC_TIMEOUT, **kwargs: Any) -> Any:
            return self._node.call(self._name, func_name, *args, timeout=timeout, **kwargs)

        return _caller

    def is_alive(self, timeout: float = 2.0) -> bool:
        """Return True if the peer responds to a ping within the timeout."""
        try:
            res = self._node.call(self._name, "__ping__", timeout=timeout)
        except (PeerTimeoutError, PeerNotFound, RemoteError, OSError):
            return False
        if isinstance(res, dict):
            return bool(res.get("ok"))
        return bool(res)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def _node_port(node_name: str) -> int:
    """Deterministic, collision-resistant port from node name."""
    digest = int(hashlib.md5(node_name.encode()).hexdigest(), 16)
    return BASE_PORT + (digest % PORT_RANGE)


def _local_ip() -> str:
    """Best-guess LAN IP (avoids 127.x loopback)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


# ─────────────────────────────────────────────────────────────────────────────
# ARP Fallback (no Zeroconf env)
# ─────────────────────────────────────────────────────────────────────────────
def arp_scan(port: int, timeout: float = 2.0) -> List[Tuple[str, int]]:
    """
    Simple ARP-like UDP probe: scans 192.168.x.0/24 for PeerLink nodes.
    Returns list of (ip, port) tuples that respond.
    """
    my_ip = _local_ip()
    prefix = ".".join(my_ip.split(".")[:3])
    results: List[Tuple[str, int]] = []
    lock = threading.Lock()

    def probe(ip: str) -> None:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(timeout)
            ping = json.dumps({"id": "arp-ping", "rpc": "__ping__", "args": []}).encode()
            s.sendto(ping, (ip, port))
            data, _ = s.recvfrom(512)
            msg = json.loads(data)
            if msg.get("result") == "pong":
                with lock:
                    results.append((ip, port))
            s.close()
        except Exception:
            pass

    threads = [
        threading.Thread(target=probe, args=(f"{prefix}.{i}",), daemon=True)
        for i in range(1, 255)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout + 0.5)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# mDNS Peer Listener (callback bridge)
# ─────────────────────────────────────────────────────────────────────────────
class _PeerListener(ServiceListener):
    def __init__(self, node: "PeerLink"):
        self._node = node

    def add_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        info = zc.get_service_info(type_, name)
        if info:
            self._node._on_peer_added(name, info)

    def remove_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        self._node._on_peer_removed(name)

    def update_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        info = zc.get_service_info(type_, name)
        if info:
            self._node._on_peer_added(name, info)


# ─────────────────────────────────────────────────────────────────────────────
# Core PeerLink Node
# ─────────────────────────────────────────────────────────────────────────────
class PeerLink:
    """
    Zero-config P2P RPC node.

    Phase 1  Bootstrap  – UDP socket + mDNS publish
    Phase 2  Discovery  – ServiceBrowser auto-populates peers
    Phase 3  RPC call   – UDP fire → await reply event
    Phase 4  Swarm      – call("ALL", ...) fans out in parallel
    """

    def __init__(self, node_name: str, verbose: bool = True):
        self.node_name = node_name
        self.verbose = verbose
        self.port = _node_port(node_name)

        # Local RPC handlers and peer cache
        self._handlers: Dict[str, Callable[..., Any]] = {}
        self._peers: Dict[str, PeerInfo] = {}  # peer_name → PeerInfo
        self._pending: Dict[str, PendingCall] = {}  # call_id → PendingCall

        self._lock = threading.Lock()
        self._running = False

        # Networking handles (set on start)
        self._sock: Optional[socket.socket] = None
        self._server_thread: Optional[threading.Thread] = None
        self._zeroconf: Optional[Zeroconf] = None
        self._service_info: Optional[ServiceInfo] = None
        self._browser: Optional[ServiceBrowser] = None

        # Built-in ping (liveness + ARP fallback probe target)
        self._handlers["__ping__"] = lambda: {"ok": True, "time": time.time()}

        # Configure logging if verbose
        if self.verbose:
            if not logger.handlers:
                handler = logging.StreamHandler()
                formatter = logging.Formatter(
                    "[%(asctime)s][peerlink][%(levelname)s] %(message)s",
                    datefmt="%H:%M:%S",
                )
                handler.setFormatter(formatter)
                logger.addHandler(handler)
            logger.setLevel(logging.INFO)

    # ── Public API ────────────────────────────────────────────────────

    def register(self, name: str, func: Callable[..., Any]) -> "PeerLink":
        """Register an RPC function. Chainable."""
        self._handlers[name] = func
        return self

    def start(self) -> "PeerLink":
        """
        Bootstrap sequence:
          1. Bind UDP socket (SOCK_REUSEADDR)
          2. Publish mDNS service record
          3. Launch ServiceBrowser for peer discovery
        """
        self._start_udp_server()
        self._publish_mdns()
        self._start_discovery()
        self._log(f"🚀 Node-{self.node_name} [{self.port}] online")
        return self

    def stop(self) -> None:
        """Graceful teardown: unregister mDNS, close UDP socket."""
        self._running = False
        try:
            if self._browser:
                self._browser.cancel()
            if self._zeroconf and self._service_info:
                self._zeroconf.unregister_service(self._service_info)
                self._zeroconf.close()
            if self._sock:
                self._sock.close()
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("Shutdown error: %s", exc)
        self._log(f"🛑 Node-{self.node_name} stopped")

    def call(
        self,
        target: str,
        func_name: str,
        *args: Any,
        timeout: float = RPC_TIMEOUT,
        **kwargs: Any,
    ) -> Any:
        """
        Make an RPC call.

        target=\"ALL\"   → fan-out broadcast, returns {peer_name: result}
        target=\"Phone1\" → unicast, returns single result value
        """
        if target.strip().upper() == "ALL":
            return self._call_all(func_name, *args, timeout=timeout, **kwargs)
        return self._call_one(target, func_name, *args, timeout=timeout, **kwargs)

    def wait_for_peers(self, count: int = 1, timeout: float = 30.0) -> bool:
        """Block until at least `count` peers are discovered (or timeout)."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                if len(self._peers) >= count:
                    return True
            time.sleep(0.2)
        return False

    def peer_names(self) -> List[str]:
        """Return human-readable list of discovered peer names."""
        self._prune_peers()
        with self._lock:
            return sorted(self._peers.keys())

    def peer(self, name: str) -> PeerProxy:
        """
        Return a PeerProxy for attribute-based calls: peer("Phone1").add(1, 2).

        Raises PeerNotFound if the peer is not currently known.
        """
        if self._resolve_peer(name) is None:
            raise PeerNotFound(f"Peer '{name}' not found")
        return PeerProxy(self, name)

    # ── Context manager ───────────────────────────────────────────────

    def __enter__(self) -> "PeerLink":
        return self.start()

    def __exit__(self, *_: object) -> None:
        self.stop()

    def __repr__(self) -> str:  # pragma: no cover - repr only
        return (
            f"<PeerLink node={self.node_name!r} "
            f"port={self.port} peers={len(self._peers)}>"
        )

    # ── Phase 1: UDP server ───────────────────────────────────────────

    def _start_udp_server(self) -> None:
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self._sock.bind(("", self.port))
        except OSError as exc:
            raise PeerLinkError(
                f"Cannot bind UDP port {self.port} for node '{self.node_name}': {exc}"
            ) from exc
        self._sock.settimeout(1.0)
        self._running = True
        self._server_thread = threading.Thread(
            target=self._server_loop,
            daemon=True,
            name=f"peerlink-{self.node_name}",
        )
        self._server_thread.start()
        self._log(f"UDP server bound on port {self.port}")

    def _server_loop(self) -> None:
        """Receive UDP packets in a tight loop."""
        while self._running:
            try:
                data, addr = self._sock.recvfrom(MAX_DATAGRAM)
            except socket.timeout:
                # periodic peer pruning while idle
                self._prune_peers()
                continue
            except OSError:
                break
            try:
                msg = json.loads(data.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                logger.warning("Malformed packet from %s", addr)
                continue
            threading.Thread(
                target=self._handle_message,
                args=(msg, addr),
                daemon=True,
            ).start()

    def _handle_message(self, msg: dict, addr: Tuple[str, int]) -> None:
        msg_type = msg.get("type")

        # Backwards compatibility: if no explicit type but has "rpc", treat as request
        if msg_type == "request" or ("rpc" in msg and msg_type is None):
            self._dispatch_rpc(msg, addr)
        elif msg_type in {"response", "error"} or "result" in msg or "error" in msg:
            call_id = msg.get("id")
            with self._lock:
                pending = self._pending.get(call_id)
            if pending:
                pending.result = msg
                pending.event.set()

    def _dispatch_rpc(self, msg: dict, addr: Tuple[str, int]) -> None:
        call_id = msg.get("id")
        func_name = msg.get("rpc", "")
        args = msg.get("args", [])
        kwargs = msg.get("kwargs", {})

        if func_name in self._handlers:
            try:
                result = self._handlers[func_name](*args, **kwargs)
                resp: Dict[str, Any] = {
                    "type": "response",
                    "id": call_id,
                    "result": result,
                }
            except Exception as exc:  # pragma: no cover - remote execution path
                resp = {
                    "type": "error",
                    "id": call_id,
                    "error": {
                        "type": type(exc).__name__,
                        "message": str(exc),
                    },
                }
        else:
            resp = {
                "type": "error",
                "id": call_id,
                "error": {
                    "type": "RemoteError",
                    "message": f"No function '{func_name}' registered",
                },
            }

        try:
            payload = json.dumps(resp).encode("utf-8")
            if len(payload) > MAX_DATAGRAM:
                logger.error("Response too large to send (size=%d bytes)", len(payload))
                return
            self._sock.sendto(payload, addr)
        except OSError as exc:  # pragma: no cover - network failure
            logger.warning("Reply to %s failed: %s", addr, exc)

    # ── Phase 2: mDNS Discovery ───────────────────────────────────────

    def _publish_mdns(self) -> None:
        local_ip = _local_ip()
        self._zeroconf = Zeroconf()
        self._service_info = ServiceInfo(
            type_=SERVICE_TYPE,
            name=f"{self.node_name}.{SERVICE_TYPE}",
            addresses=[socket.inet_aton(local_ip)],
            port=self.port,
            properties={
                "node": self.node_name,
                "port": str(self.port),
                "version": __version__,
            },
            server=f"{self.node_name}.local.",
        )
        self._zeroconf.register_service(self._service_info)

    def _start_discovery(self) -> None:
        listener = _PeerListener(self)
        self._browser = ServiceBrowser(self._zeroconf, SERVICE_TYPE, listener)

    def _on_peer_added(self, mdns_key: str, info: ServiceInfo) -> None:
        # Skip self
        if self.node_name.lower() in mdns_key.lower():
            return
        props = info.decoded_properties or {}
        peer_name = props.get("node", mdns_key.split(".")[0])
        addr = socket.inet_ntoa(info.addresses[0]) if info.addresses else None
        port = info.port
        if not addr:
            return
        now = time.time()
        with self._lock:
            self._peers[peer_name] = PeerInfo(
                name=peer_name,
                addr=addr,
                port=port,
                last_seen=now,
            )
        self._log(f"👥 Found peer: {peer_name} @ {addr}:{port}")

    def _on_peer_removed(self, mdns_key: str) -> None:
        # mdns_key is service name; resolve approximate peer_name
        name = mdns_key.split(".")[0]
        with self._lock:
            removed = self._peers.pop(name, None)
        if removed:
            self._log(f"💀 Lost peer: {removed.name}")

    def _prune_peers(self) -> None:
        """Drop peers that have exceeded their TTL."""
        now = time.time()
        with self._lock:
            expired = [
                name
                for name, info in self._peers.items()
                if now - info.last_seen > info.ttl
            ]
            for name in expired:
                self._peers.pop(name, None)
                self._log(f"⌛ Peer expired: {name}")

    # ── Phase 3: RPC call engine ──────────────────────────────────────

    def _resolve_peer(self, target: str) -> Optional[Tuple[str, int]]:
        """Fuzzy-match target name → (ip, port)."""
        self._prune_peers()
        t = target.lower()
        with self._lock:
            for name, info in self._peers.items():
                if t in name.lower():
                    return info.addr, info.port
        return None

    def _call_one(
        self,
        target: str,
        func_name: str,
        *args: Any,
        timeout: float,
        **kwargs: Any,
    ) -> Any:
        peer_addr = self._resolve_peer(target)
        if peer_addr is None:
            with self._lock:
                known = list(self._peers.keys())
            raise PeerNotFound(f"Peer '{target}' not found. Known peers: {known}")

        call_id = str(uuid.uuid4())
        event = threading.Event()
        pending = PendingCall(id=call_id, event=event)
        with self._lock:
            self._pending[call_id] = pending

        msg = {
            "type": "request",
            "id": call_id,
            "src": self.node_name,
            "dst": target,
            "rpc": func_name,
            "args": list(args),
            "kwargs": kwargs,
        }
        payload = json.dumps(msg).encode("utf-8")
        if len(payload) > MAX_DATAGRAM:
            with self._lock:
                self._pending.pop(call_id, None)
            raise PeerLinkError(
                f"Payload too large for UDP datagram ({len(payload)} bytes)"
            )

        self._log(f"RPC {func_name} → {target} (id={call_id})")
        self._sock.sendto(payload, peer_addr)

        fired = event.wait(timeout=timeout)
        with self._lock:
            reply = (
                self._pending.pop(call_id, None).result
                if call_id in self._pending
                else pending.result
            )

        if not fired or reply is None:
            self._log(f"RPC {func_name} → {target} (id={call_id}) timed out")
            raise PeerTimeoutError(
                f"RPC '{func_name}' → '{target}' timed out after {timeout}s"
            )

        if reply.get("type") == "error" or "error" in reply:
            err = reply.get("error")
            if isinstance(err, dict):
                raise RemoteError(f"{err.get('type')}: {err.get('message')}")
            raise RemoteError(str(err))

        return reply.get("result")

    # ── Phase 4: Swarm broadcast ──────────────────────────────────────

    def _call_all(
        self,
        func_name: str,
        *args: Any,
        timeout: float,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Fan-out RPC to every known peer in parallel threads."""
        self._prune_peers()
        with self._lock:
            snapshot = list(self._peers.items())

        results: Dict[str, Any] = {}
        lock = threading.Lock()

        def worker(peer_name: str, _: PeerInfo) -> None:
            try:
                res = self._call_one(
                    peer_name, func_name, *args, timeout=timeout, **kwargs
                )
                with lock:
                    results[peer_name] = res
            except Exception as exc:
                # Capture per-peer failures as exception instances (e.g. RemoteError,
                # PeerNotFound, PeerTimeoutError) instead of stopping the whole call.
                with lock:
                    results[peer_name] = exc

        threads = [
            threading.Thread(target=worker, args=(name, info), daemon=True)
            for name, info in snapshot
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout + 1)

        return results

    # ── Logging ───────────────────────────────────────────────────────

    def _log(self, msg: str) -> None:
        if self.verbose:
            ts = time.strftime("%H:%M:%S")
            print(f"[{ts}][PeerLink:{self.node_name}] {msg}")


# ─────────────────────────────────────────────────────────────────────────────
# SwarmNode — High-level convenience wrapper
# ─────────────────────────────────────────────────────────────────────────────
class SwarmNode(PeerLink):
    """
    Auto-started PeerLink node. Designed for context-manager usage.

    Example:
        with SwarmNode("RPi4") as node:
            node.register("matrix_chunk", compute)
            node.wait_for_peers(2)
            results = node.call("ALL", "matrix_chunk", data)
    """

    def __init__(self, node_name: str, **kwargs: Any):
        super().__init__(node_name, **kwargs)
        self.start()

